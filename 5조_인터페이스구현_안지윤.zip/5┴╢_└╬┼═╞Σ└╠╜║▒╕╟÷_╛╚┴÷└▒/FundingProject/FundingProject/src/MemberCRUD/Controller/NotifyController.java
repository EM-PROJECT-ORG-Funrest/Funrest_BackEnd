package MemberCRUD.Controller;

import java.util.Map;

public class NotifyController implements SubController{

	
	//1 Insert, 2 Update(필요없음), 3 Delete, 4 SelectAll, 5 Select(필요없음)
	@Override
	public Map<String, Object> execute(int serviceNo, Map<String, Object> params) {
		// TODO Auto-generated method stub
		return null;
	}

}
